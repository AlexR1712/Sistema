<?php 
    $host_db = "mysql.megahosting.com.ve"; // Host de la BD 
    $usuario_db = "u615841055_sys2"; // Usuario de la BD 
    $clave_db = "fUfsJFzpzb"; // Contraseña de la BD 
    $nombre_db = "u615841055_sys2"; // Nombre de la BD 
     
    //conectamos y seleccionamos db 
    mysql_connect($host_db, $usuario_db, $clave_db) or die('No pudo conectarse: ' . mysql_error());
    mysql_select_db($nombre_db) or die('No pudo conectarse: ' . mysql_error()); 
?>